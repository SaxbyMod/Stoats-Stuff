### Includes:

<details>
<summary>16 New Tribes:
</summary>

|GUID|Name|Cards|
|:-:|:-|:-|
|tribes.libary|cells|0|
|tribes.libary|ceromorph|0|
|tribes.libary|conduits|0|
|tribes.libary|everything|0|
|tribes.libary|fleshy|0|
|tribes.libary|fungus|0|
|tribes.libary|guardian|0|
|tribes.libary|mox|0|
|tribes.libary|rodent|0|
|tribes.libary|scholar|0|
|tribes.libary|security|0|
|tribes.libary|skeletal|0|
|tribes.libary|spectral|0|
|tribes.libary|tentacle|0|
|tribes.libary|utillity|0|
|tribes.libary|vessel|0|
</details>

### credits:

Miner Man Guy#7536 For the Tribe art of Cells, Conduits, fleshy, guardian, mox, scholar, security, skeletal, spectral, utility,  vessel, ceromorph

Pixel Profligate#6969 for the art of Tentacle, Everything, Fungus

The Stoat Lord [He/Him] Bi#7859 Made the CARD BACKS(as in the choice nodes) for Cells, Conduits, fleshy, guardian, mox, scholar, security, skeletal, spectral, utility,  vessel Tentacle, Everything, Fungus, Rodent, ceromorph

Also You may use the blank  card backs included in the art folder for what ever you want

Jghbug7#8304 The Tribe icon for Rodent

### todo:

Make more of fanscryptions Tribes

### Changelog:

1.0.0 Release

1.1.0 Made Skeletal work

1.2.0 added Pixels Tribes

1.3.0 Made Card backs for all tribes

1.4.0 Added rodent

1.5.0 Fixed art a Bit (Probably will be redone again) Also added another Tribe

1.6.0 Fixed the credits

1.7.0 Fixed the art again NO TRANSPARENCY YAY!!!

### Info:

Discord Server Link: https://discord.gg/6dUgPufUz6
