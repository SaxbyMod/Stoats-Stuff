Link to what was used to make this is set as the "Website Link"

### Includes:

<details>
<summary>56 New Ascension Starter Decks:
</summary>

|Name|Unlock Level|Cards|
|:-|:-|:-|
|Eight|0| Amalgam,  Alpha,  Raven|
|Five|0| Greater Smoke,  Ourobot,  Skink|
|Four|0| M3atB0t,  Busted 3D Printer,  Necromancer|
|Nine|0| Wolf Pelt,  Burrowing Trap,  Sapphire Vessel|
|One|0| Wolf Pelt,  Beehive,  Frank & Stein|
|Seven|0| Amalgam,  Alpha,  Raven|
|Six|0| The Smoke,  Coyote,  Gravedigger|
|Ten|0| Stim Mage,  Shieldbot,  Mummy Lord|
|Thirty_five|0| Ruby Vessel,  Gift Bot,  Moose Buck|
|Three|0| Skeleton,  Revenant,  Stim Mage|
|True_Rng|0||
|Two|0| Heal Conduit,  Energy Conduit,  Heal Conduit|
|eighteen|0| Skunk,  Elk Fawn,  Master Bleene|
|eleven|0| Mrs. Bomb,  Mantis God,  Gold Nugget|
|fifteen|0| Warren,  Master Bleene,  Plasma Jimmy|
|fifty|0| Elk,  Wriggling Tail,  Mrs. Bomb|
|fifty_five|0| Rabbit Pelt,  Wolf Cub,  Wolf Pelt|
|fifty_four|0| Squirrel,  Spore Mice,  Pronghorn|
|fifty_one|0| Amalgam,  River Otter,  Gift Bot|
|fifty_three|0| Frozen Opossum,  Opossum,  Bleene's Vessel|
|fifty_two|0| Gem Detonator,  Kind Cell|
|forty|0| Orange Mage,  Boulder,  Mummy Lord|
|forty_eight|0| GR1ZZ,  Energy Conduit,  Energy Bot|
|forty_five|0| Strange Larva,  Mummy Lord,  Mole|
|forty_four|0| Banshee,  Beaver,  QU177|
|forty_nine|0| Shield Latcher,  Bait Bucket,  Urayuli|
|forty_one|0| Leaping Trap,  Child 13,  Greater Smoke|
|forty_seven|0| Energy Conduit,  Sentry Drone|
|forty_six|0| Orlu's Vessel,  GR1ZZ,  Gift Bot|
|forty_three|0| Beehive,  Fishbot,  Factory Conduit|
|forty_two|0| Mummy Lord,  Porcupine,  Bomb Latcher|
|fourteen|0| Dead Tree,  Necromancer,  Strange Frog|
|nineteen|0| Orange Mage,  Gamblobot,  Field Mice|
|seventeen|0| Force Mage,  Green Mage,  Skunk|
|sixteen|0| Long Elk,  Hawk,  Bullfrog|
|thirteen|0| Draugr,  Gem Guardian,  Heal Conduit|
|thirty|0| Emerald Vessel,  Lammergeier,  Orange Mage|
|thirty_eight|0| Goranj's Mox,  Kingfisher,  49er|
|thirty_four|0| Chime,  Sarcophagus,  Bat|
|thirty_nine|0| Tail Feathers,  The Smoke,  Ruby Mox|
|thirty_one|0| Skelemagus,  Gift Bot,  Moose Buck|
|thirty_seven|0| Blue Mage,  S0N1A,  Hand Tentacle|
|thirty_six|0| Rat King,  Hawk,  Tough Cell|
|thirty_three|0| Energy Bot,  Magpie,  Steambot|
|thirty_two|0| Cat,  Strange Frog,  Cat|
|twelve|0| Gamblobot,  Strange Pupa,  Sentry Drone|
|twenty|0| Urayuli,  Squirrel Ball,  Worker Ant|
|twenty_eight|0| Mrs. Bomb,  Junior Sage,  Strange Larva|
|twenty_five|0| Cockroach,  Raven Egg,  Boulder|
|twenty_four|0| Strange Larva,  Tough Cell,  Spore Mice|
|twenty_nine|0| Corpse Maggots,  Gravedigger,  Double Gunner|
|twenty_one|0| Dead Tree,  Shieldbot,  Worker Ant|
|twenty_seven|0| Bloodhound,  River Otter,  Grizzly|
|twenty_six|0| Ant Queen,  Mole,  Gembound Ripper|
|twenty_three|0| Pronghorn,  Great White,  Mummy Lord|
|twenty_two|0| Cockroach,  Alarm Bot,  Bell Tentacle|
</details>
