## This is not a balanced Mod Jsyn


## This is a kcm mod that adds vanila themed deck there will be more to come Currently adds 17 decks

## Changelog 

<details>
<summary>Changelog</summary>

1.0.0 4 decks created

1.0.1 Added Talkers deck

1.0.2 added bee deck

1.0.3 added tentacle deck

1.0.4 added dogs deck

1.0.5 added trap and snake decks

1.0.6 Readme fix

1.0.7 added bait and smoke decks

1.0.8 Defense deck added

1.1.1 Changed trap deck 

1.1.2 added 2nd dogs deck, sacrifices deck and a energy deck

1.1.3 Readme Fix

1.1.4 Bone deck

1.1.5 Readme fix

1.1.6 Art redone
</details>