Drip Jouta Kujo#1234 made the green mox and blur mox and likely the orange mox too

1.0.0 added base mox cards and the 4 main scrybes Magnificus is currently bugged fyi

1.0.1 Fixed leshy and grimora images also nerfed some of the cards and added Pokemon scrybe

1.0.2 made pokemon scrybe spawnable