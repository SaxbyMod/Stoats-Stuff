Update for starters soon

### Includes:
- 128 New Cards:
- 154 New Sigils:

<details>
<summary>Cards:
</summary>

|Name|Power|Health|Cost|Evolution|Sigils|Specials|Traits|Tribes|
|-|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
|starvation|1|1|Free|| Repulsive|||None|
|starvation 108|1|1|Free|| Haste|||None|
|Starvation1|1|1|Free|| Rabbit Hole|||None|
|starvation10|1|1|Free|| Loose Tail|||None|
|starvation100|1|1|Free|| Ram|||None|
|starvation101|1|1|Free|| Drink Me|||None|
|starvation102|1|1|Free|| Golden Nugget|||None|
|starvation103|1|1|Free|| Transient|||None|
|starvation104|1|1|Free|| Grazing|||None|
|starvation105|1|1|Free|| Brimstone|||None|
|Starvation106|1|1|Free|| Eat Me|||None|
|starvation107|1|1|Free|| Right scratch|||None|
|starvation109|1|1|Free|| To The Slaughter|||None|
|starvation11|1|1|Free|| Corpse Eater|||None|
|starvation110|1|1|Free|| Tooth Bargain|||None|
|starvation111|1|1|Free|| Toothpuller|||None|
|starvation112|1|1|Free|| Thick Shell|||None|
|starvation113|1|1|Free|| Thief|||None|
|starvation114|1|1|Free|| Superior Sacrifice|||None|
|starvation115|1|1|Free|| Support call|||None|
|starvation116|1|1|Free|| Electric|||None|
|starvation117|1|1|Free|| Herd|||None|
|starvation118|1|1|Free|| Random Strafe|||None|
|starvation119|1|1|Free|| Dying|||None|
|starvation12|1|1|Free|| Bone King|||None|
|starvation120|1|1|Free|| Enforcer|||None|
|starvation124|1|1|Free|| Ambush|||None|
|starvation125|1|1|Free|| Hourglass|||None|
|starvation126|1|1|Free|| Asleep|||None|
|starvation128|1|1|Free|| Imbuing|||None|
|starvation129|1|1|Free|| Activated Latch Nano Shield|||None|
|starvation13|1|1|Free|| Waterborne|||None|
|starvation14|1|1|Free|| Unkillable|||None|
|starvation15|1|1|Free|| Sharp Quills|||None|
|starvation16|1|1|Free|| Hefty|||None|
|starvation17|1|1|Free|| Ant Spawner|||None|
|starvation18|1|1|Free|| Guardian|||None|
|starvation19|1|1|Free|| Airborne|||None|
|Starvation2|1|1|Free|| Bees Within|||None|
|starvation20|1|1|Free|| Many Lives|||None|
|starvation21|1|1|Free|| Worthy Sacrifice|||None|
|starvation22|1|1|Free|| Mighty Leap|||None|
|starvation23|1|1|Free|| Bifurcated Strike|||None|
|starvation24|1|1|Free|| Trifurcated Strike|||None|
|starvation25|1|1|Free|| Frozen Away|||None|
|starvation26|1|1|Free|| Bone Digger|||None|
|starvation28|1|1|Free|| Steel Trap|||None|
|starvation29|1|1|Free|| Amorphous|||None|
|starvation3|1|1|Free|| Sprinter|||None|
|starvation30|1|1|Free|| Tidal Lock|||None|
|starvation31|1|1|Free|| Moon Strike|||None|
|starvation32|1|1|Free|| Leader|||None|
|starvation33|1|1|Free|| Brittle|||None|
|starvation34|1|1|Free|| Skeleton Crew|||None|
|starvation35|1|1|Free|| Green Mox|||None|
|starvation36|1|1|Free|| Orange Mox|||None|
|starvation37|1|1|Free|| Blue Mox|||None|
|starvation38|1|1|Free|| Gem Animator|||None|
|starvation39|1|1|Free|| Ruby Heart|||None|
|starvation4|1|1|Free|| Touch of Death|||None|
|starvation40|1|1|Free|| Mental Gemnastics|||None|
|starvation41|1|1|Free|| Gem Dependant|||None|
|starvation42|1|1|Free|| Great Mox|||None|
|starvation43|1|1|Free|| Handy|||None|
|starvation44|1|1|Free|| Squirrel Shedder|||None|
|starvation45|1|1|Free|| Attack Conduit|||None|
|starvation46|1|1|Free|| Spawn Conduit|||None|
|starvation47|1|1|Free|| Healing Conduit|||None|
|starvation48|1|1|Free|| Null Conduit|||None|
|starvation49|1|1|Free|| Battery Bearer|||None|
|starvation5|1|1|Free|| Fledgling|||None|
|starvation50|1|1|Free|| Detonator|||None|
|starvation51|1|1|Free|| Sniper|||None|
|starvation52|1|1|Free|| Nano Armor|||None|
|starvation53|1|1|Free|| Overclocked|||None|
|starvation54|1|1|Free|| Bomb Latch|||None|
|starvation55|1|1|Free|| Brittle Latch|||None|
|starvation56|1|1|Free|| Shield Latch|||None|
|starvation57|1|1|Free|| Dead Byte|||None|
|starvation58|1|1|Free|| Hostage File|||None|
|starvation59|1|1|Free|| Transformer|||None|
|starvation6|1|1|Free|| Dam Builder|||None|
|starvation60|1|1|Free|| Sentry|||None|
|Starvation61|1|1|Free|| Gem Detonator|||None|
|starvation62|1|1|Free|| Gem Guardian|||None|
|starvation63|1|1|Free|| Vessel Printer|||None|
|Starvation64|1|1|Free|| Energy Conduit|||None|
|starvation65|1|1|Free|| Bomb Spewer|||None|
|starvation66|1|1|Free|| Handy|||None|
|starvation67|1|1|Free|| Power Dice|||None|
|starvation68|1|1|Free|| Enlarge|||None|
|starvation69|1|1|Free|| Swapper|||None|
|starvation7|1|1|Free|| Hoarder|||None|
|starvation70|1|1|Free|| Disentomb|||None|
|starvation71|1|1|Free|| Energy Gun|||None|
|starvation72|1|1|Free|| Bellist|||None|
|starvation73|1|1|Free|| Annoying|||None|
|starvation74|1|1|Free|| Gem Spawn Conduit|||None|
|starvation75|1|1|Free|| Gift Bearer|||None|
|starvation76|1|1|Free|| Looter|||None|
|starvation77|1|1|Free|| True Scholar|||None|
|starvation78|1|1|Free|| Stimulate|||None|
|starvation79|1|1|Free|| Stinky|||None|
|starvation8|1|1|Free|| Burrower|||None|
|starvation83|1|1|Free|| Bonehorn|||None|
|starvation84|1|1|Free|| Clinger|||None|
|starvation85|1|1|Free|| Waterborne|||None|
|starvation86|1|1|Free|| Giant|||None|
|starvation87|1|1|Free|| Antler Bearer|||None|
|starvation88|1|1|Free|| Acidic Trail|||None|
|starvation89|1|1|Free|| Abundance|||None|
|Starvation9|1|1|Free|| Fecundity|||None|
|Starvation90|1|1|Free|| Abundance|||None|
|starvation91|1|1|Free|| Activated Latch Explode On Death|||None|
|starvation93|1|1|Free|| Box|||None|
|starvation94|1|1|Free|||||None|
|starvation95|1|1|Free|| Appetizing Target|||None|
|starvation96|1|1|Free|| Frightful|||None|
|starvation97|1|1|Free|| Draw Jackalope|||None|
|starvation98|1|1|Free|| Tribal Ally|||None|
|starvation99|1|1|Free|| Trample|||None|
</details>

<details>
<summary>Rare Cards:
</summary>

|Name|Power|Health|Cost|Evolution|Sigils|Specials|Traits|Tribes|
|-|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
|Starvation121|1|1|Free|| Random Strike|||None|
|starvation122|1|1|Free|| Broken|||None|
|starvation123|1|1|Free|| Split|||None|
|starvation127|1|1|Free|| Predator|||None|
|starvation130|1|1|Free|| Wild hunger|||None|
|starvation131|1|1|Free|| Instant|||None|
|starving ourobourus|1|1|Free|| Unkillable| Ouroboros||None|
</details>

<details>
<summary>Sigils:
</summary>

|Name|Description|
|-|-|
|Abundance|A card bearing this sigil will grant one tooth per instance of Abundance when killed.|
|Acidic Trail|At the end of the owner's turn, A card bearing this sigil will move in the direction inscribed in the sigil, and deal 1 damage to the opposing creature if it is able to move.|
|Activated Latch Brittle|When activated for a cost of 1 energy will allow the owner to give a creature Brittle.|
|Activated Latch Explode On Death|When activated for a cost of 1 energy will allow the owner to give a creature Explode On Death.|
|Activated Latch Nano Shield|When activated for a cost of 1 energy / 2 bones will allow the owner to give a creature Nano Shield.|
|Activated Latch Reach|When activated for a cost of 2 energy will allow the owner to give a creature Reach.|
|Agile|When a card bearing this sigil would be struck, it will move out of the way.|
|All seeing|While a card bearing this sigil is on the board, all talking cards on your side of the board get +2 health.|
|Ambush|When a creature moves into the space opposing a card bearing this sigil, they are dealt 1 damage.|
|Antler Bearer|When A card bearing this sigil is killed, gain three random hooved tribe cards.|
|Appetizing Target|A card bearing this sigil makes for a great target, causing the creature opposing a card bearing this sigil to gain 1 power.|
|Asleep|A card bearing this sigil has 0 attack for as long as it has this sigil, and this sigil will be removed after 1 turn.|
|Bait|When an opposing creature is played and there is no card opposite of the card bearing this sigil, the opposing create will move to that spot.|
|Belligerent|When A card bearing this sigil dies, create a copy of itself with a cumulative -1 to Power and Health. Has no effect on cards with 1 Health.|
|Blight|When A card bearing this sigil is sacrificed, it subtracts its stat values to the card it was sacrificed for.|
|Blood Growth|When A card bearing this sigil attacks, the amount of blood it is counted as when sacrificed will increase.|
|Blood shifter|When a card bearing this sigils kills another card, it will turn into that card.|
|BloodGuzzler|A card bearing this sigil deals damage, it gains 1 Health for each damage dealt.|
|Bodyguard|A card bearing this sigil will redirect the initial attack of a card to it, if the attack was targeting an adjacent space.|
|Bombardier|A card bearing this sigil will deal 10 damage to a random creature during the end phase of the owner's turn.|
|Bond|When a creature bearing this sigil has a adjacent creature it will gain +1 attack/health dependent on which side the adjacent creature is.|
|Bone Picker|A card bearing this sigil kills a creature, it will generate 1 Bone.|
|Bone hoarder 1|When a card bearing this sigil is played, 1 bone is rewarded.|
|Bone hoarder 2|When a card bearing this sigil is played, 2 bone is rewarded.|
|Bone hoarder 3|When a card bearing this sigil is played, 3 bone is rewarded.|
|Bone lord 5|When a card bearing this sigil dies, 5 bones are rewarded instead of 1.|
|Bone lord 6|When a card bearing this sigil dies, 6 bones are rewarded instead of 1.|
|Bone prince 2|When a card bearing this sigil dies, 2 bones are rewarded instead of 1.|
|Bone prince 3|When a card bearing this sigil dies, 3 bones are rewarded instead of 1.|
|Boneless|A card bearing this sigil gives no bones! Any bones gained from sigils or death will be negated.|
|Box|A card bearing this sigil will get removed from your deck on death, and a new creature contained within will be added to it.|
|Brimstone|Does not affect Terrain or Pelts. When A card bearing this sigil damages another card, overkill damage will always happen, but damage is set to 1. If no card is queued to take overkill damage, your opponent takes 1 damage instead.|
|Broken|A card bearing this sigil is permanently removed from your deck if it dies.|
|Burning|A card bearing this sigil is on fire, and will gain 1 power and loose 1 health each upkeep.|
|Cannibal|At the end of your turn, A card bearing this sigil will steal 1 health from adjacent creatures of the same tribe.|
|Caustic|At the end of the towner's turn, A card bearing this sigil will move in the direction inscribed in the sigil, and drop an acid puddle in their old space.|
|Charge|Pay 3 bones to choose a enemy creature that a card bearing this sigil will strike.|
|Chicken|A card with this sigil counts as a Chicken.|
|Coin Finder|At the end of the owner's turn, A card bearing this sigil will grant the owner 1 foil.|
|Consumer|When A card bearing this sigil kills another creature, it gains 2 health.|
|Cowardly|A card bearing this sigil will not attack a card with a power 2 higher than its own.|
|Death Marked|This sigil is not for you, player.|
|Deathburst|A card bearing this sigil will deal 1 damage to each oppsing space to the left, right, and center of it.|
|Desperate|A card bearing this sigil's power is equal to its missing Health.|
|Desperation|A card bearing this sigil is damaged to 1 health, it will gain 3 power.|
|Disease Absorbtion|When played, A card bearing this sigil will take all negative sigils onto itself.|
|Docile|At the start of the owner's turn, a creature bearing this sigil will lose 1 Power to gain 1 Health.|
|Double scratch|When a card bearing this sigil attacks it attacks twice and the space right and left of the attacked slot.|
|Draw Blood|A card bearing this sigil is played, a card costing blood is created in your hand.|
|Draw Bone|A card bearing this sigil is played, a card costing bone is created in your hand.|
|Draw Card|A card bearing this sigil is played, a card relating to it's ice cube parameter (default Opossum) is created in your hand.|
|Draw Jackalope|A card bearing this sigil is played, a Jackalope is created in your hand.|
|Drink Me|A creature gains 1 power and loses 1 health when summoned using A card bearing this sigil as a sacrifice.|
|Dwarf|When A card bearing this sigil is drawn, it will loose one unit of cost, as well as 1 power and 2 health (can't go below 1 health). A unit is defined as: 1 blood, 3 bones, 3 energy, or all mox.|
|Dying|A card bearing this sigil will lose 1 health each time it declares an attack.|
|Eat Me|A creature loses 1 power and gains 1 health when summoned using A card bearing this sigil as a sacrifice.|
|Electric|When A card bearing this sigil decalres an attack, they will deal half the damage to creatures adjacent to the target.|
|Enforcer|At the start of the owner's turn, A card bearing this sigil will cause adjacent creatures to attack.|
|Enrage|A card bearing this sigil will empower adjacent allies, increasing their strenght by 2. However, if they perish while empowered, they are permamently removed from your deck.|
|Entomophage|A card bearing this sigil will deal 2 additional damage to cards of the insect tribe.|
|Evolve Randomly|A card bearing this sigil will grow into a random form after 1 turn on the board.|
|Excavator|When A card bearing this sigil is played, remove all Terrain cards on your side of the field. For each card removed, place a Squirrel in your hand.|
|Exhaustion|The attack of a card bearing this sigil will be decreased by the same amount as its lost health.|
|Familiar|A familiar will help with attacking when it's adjacent allies attack a card.|
|Fearful|When a card bearing this sigil is struck without it resulting in death, it will be returned to the owner's hand.|
|Firestarter|When A card bearing this sigil damages another creature, that creature will gain the Burning Sigil. The Burning Sigil is define as: Each upkeep, this creature gains 1 strength but looses 1 health.|
|Fish Hook|When A card bearing this sigil, a targeted card is moved to your side of the board.|
|Flight of the Valkyrie|When A card bearing this sigil is played, fill all open slots on your side of the field with 1/1 Norse Warriors. [define:SigilADay_julianperge_NorseWarrior]|
|Frightful|A card bearing this sigil will cause opposing creatures to move out of the way when it attacks.|
|Giant|When A card bearing this sigil is drawn, it will gain one unit blood of cost, as well as one attack and two health.|
|Golden Nugget|When A card bearing this sigil dies, gain 1 gold tooth|
|Grazing|At the end of the owner's turn, A card bearing this sigil will regen 1 health if there is no opposing creature.|
|Haste|A card bearing this sigil will attack as soon as it gets played on the board.|
|Herd|A card bearing this sigil will summon a copy of itself each upkeep, up to three times.|
|Host|A card bearing this sigil is the host of other creatures. It will give you such creature when struck.|
|Hourglass|A card bearing this sigil will cause the opponant to skip their turn when played.|
|Imbuing|A card bearing this sigil will get specific buffs depending on which tribe is most promenent in the sacrifices that were used to summon the card.|
|Instant|A card bearing this sigil will perish immediately after its played.|
|Launcher|At the end of the owner's turn, a card bearing this sigil will create another creature on a random empty space on the owner's side of the table.|
|Leech|When A card bearing this sigil deals damage, it will heal 1 Health for each damage dealt to a card.|
|Left scratch|When a card bearing this sigil attacks it also attacks the space on the left of the attacked slot.|
|Life Gambler|At the end of the owner's turn, A card bearing this sigil will deal 2 damage to the owner in exchange for a 0 to 6 increase in stats. Failing to pay this cost will result in death.|
|Linguist|While a card bearing this sigil is on the board, all talking cards on your side of the board get +1 attack.|
|Lure|A card bearing this sigil will cause facedown cards to become face up when attacking.|
|Maneuver|At the start of the owner's turn, A card bearing this sigil will strafe in the direction inscribed on the sigil if there is a creature in the opposing slot from it. Else it will strafe in the opposite direction inscribed on the sigil.|
|Marginally Better Sacrifice|A card bearing this sigil is counted as 2 blood rather than 1 blood when sacrificed.|
|Medic|At the start of the owner's turn, A card bearing this sigil will try heal 1 damage to a friendly card for each instance of Medic.|
|Miasma|When A card bearing this sigil dies, spawn a Greater Smoke in its place.|
|Midas|A card bearing this sigil kills a creature, it will generate 1 Foil for each instance of Midas the card has.|
|Multi-Strike|A card bearing this sigil will strike a card multiple times, if it lives through the first attack. Will not trigger -on attack- or -on damage- effects with the extra strikes.|
|Nest|When A card bearing this sigil is struck, you may select a card from a specific draw pile.|
|Nutritious|When A card bearing this sigil is sacrificed, it adds 1 power and 2 health to the card it was sacrificed for.|
|Opportunist|A card bearing this sigil will gain 1 power for each instance of Opportunist, when the opposing slot is empty.|
|Paralysis|A card bearing this sigil will only attack every other turn. Some effects from sigils may bypass this.|
|Pathetic Sacrifice|A card bearing this sigil is so pathetic, it is not a worthy or noble sacrifice. A card with this sigil is meant to stay on the board, and thus can't be targeted by the hammer.|
|Picky|A Card bearing this sigil cannnot be summoned using any free cards as sacrifice.|
|Pierce|A card bearing this sigil attacks the card in queue behind it's initial target first when declaring an attack.|
|Plague|A card bearing this sigil dies after 3 rounds. It also infects adjacent cards.|
|Poisonous|When A card bearing this sigil perishes, the creature that killed it perishes as well.|
|Possessor|When A card bearing this sigil perishes, it will grant a random friendly card it's base power and health.|
|Power from Movement|At the start of the owner's turn, A card bearing this sigil will gain 1 power and 1 health if it moved last round.|
|Predator|A card bearing this sigil will gain 1 power for each instance of Predator, when the opposing slot has a card.|
|Prideful|A card bearing this sigil will not attack a card with a power 2 lower than its own.|
|Prospect|When A card bearing this sigil damages another creature, that creature turns into a Golden Nugget. Gain 1 gold tooth upon destroying a Golden Nugget.|
|Protector|A card bearing this sigil will attacks on adjacent allies to hit directly.|
|Puppets gift|As long as a card bearing this sigil is on the board any cards with brittle won't die because of brittle.|
|Ram|A card bearing this sigil will try to ram the card infront of it when played, or every upkeep till it succeeds once. It will send the rammed target to the queue if on my side, or back to the hand if on your side. Does not work during combat.|
|Random Strafe|A card bearing this sigil is drawn, it will gain a random strafe sigil.|
|Random Strike|A card bearing this sigil will strike at opponent slots randomly when it attacks.|
|Recoil|A card bearing this sigil will take 1 damage each time they attack.|
|Regen|At the end of the owner's turn, A card bearing this sigil will regen to full health.|
|Regen 1|At the end of the owner's turn, A card bearing this sigil will regen 1 health.|
|Regen 2|At the end of the owner's turn, A card bearing this sigil will regen 2 health.|
|Regen 3|At the end of the owner's turn, A card bearing this sigil will regen 3 health.|
|Repellant|When A card bearing this sigil perishes, the creature that killed it gets pushed into the back row.|
|Resistant|A card bearing this sigil will only ever take 1 damage from most things. Some effects might bypass this.|
|Retaliate|A card bearing this sigil will strike those who strike their adjacent allies.|
|Right scratch|When a card bearing this sigil attacks it also attacks the space on the right of the attacked slot.|
|Rushing march|At the end of the owner's turn, a card bearing this sigil will move to the direction inscrybed to the sigil, if it hits a card however whilst moving, the card bearing this sigil stops and the card it hits perishes.|
|Scissors|When A card bearing this sigil is played, a targeted card cut in two.|
|Shapeshifter|A card bearing this sigil is ever changing. It will change its form once it's struck.|
|Short|A card bearing this sigil will not be blocked by an opposing creature bearing the airborn sigil.|
|Sickness|A card bearing this sigil will loose 1 attack each time it declares an attack.|
|Song of sleep|If a creature moves into the space opposing a card bearing this sigil, that creature will obtain the asleep sigil.|
|Spawner|At the end of the owners turn, a card bearing this sigil will move in the direction inscribed in the sigil and create another creature in its old space.|
|Split|When A card bearing this sigil is played, create a copy on an open space on your side of the field.|
|Stampede|A card bearing this sigil will cause adjacent creatures to attack when played on the board.|
|Submerged Ambush|A card bearing this sigil will deal 1 damage to cards that attacked over it while it was face-down.|
|Superior Sacrifice|A card bearing this sigil is counted as 4 blood rather than 1 blood when sacrificed.|
|Support call|When a card bearing this sigil is played, a card from your sidedeck is created in your hand.|
|Thick Shell|When attacked, A card bearing this sigil takes 1 less damage.|
|Thief|A card bearing this sigil will try to steal a random default sigil from an opposing creature when played, or at the start of the owner's turn until it does.|
|To The Slaughter|At the end of every turn will eat a random Chicken gaining X Attack for Targets X Health and X Health for Targets X Attack. |
|Tooth Bargain|When A card bearing this sigil is played, it will put 1 point of damage of it's opponent's side of the scale. When it perishes, it will put 2 damage on the owner's side of the scale.|
|Toothpuller|At the end of the owner's turn, A card bearing this sigil will add one point of damage to the opponent's scale.|
|Toxin|When A card bearing this sigil damages another creature, that creature looses 1 power and 1 health.|
|Toxin (Deadly)|When A card bearing this sigil damages another creature, that creature gains the Dying Sigil. The Dying Sigil is defined as: When ever a creature bearing this sigil declares an attack, they will loose one health.|
|Toxin (Sickening)|When A card bearing this sigil damages another creature, that creature gains the Sickness Sigil. The Sickness Sigil is defined as: When ever a creature bearing this sigil declares an attack, they will loose one attack.|
|Toxin (Strength)|When A card bearing this sigil damages another creature, that creature looses 1 power.|
|Toxin (Vigor)|When A card bearing this sigil damages another creature, that creature looses 1 health.|
|Trample|When A card bearing this sigil deals overkill damage to a card, the overkill damage will be sent to the owner.|
|Transform Chicken (Enemy Only)|A Creature bearing this sigil will transform a random creature on the board only on the enimies side into a Chicken. A Chicken is defined as 1 Attack, 1 Health.|
|Transform Chicken (Loose Cannon)|A Creature bearing this sigil will transform a random creature on the board into a Chicken. A Chicken is defined as 1 Attack, 1 Health.|
|Transient|At the end of the owner's turn, A card bearing this sigil will return to your hand.|
|Tribal Ally|When A card bearing this sigil is played, A card of the same tribe is created in your hand. No tribe counts as a tribe of tribeless.|
|Tribal Tutor|When A card bearing this sigil is played, you may search your deck for a card of the same tribe and take it into your hand. No tribe counts as a tribe of tribeless.|
|Tribe Attack|While a card bearing this sigil is on the board, all other cards on your side of the board of the same tribe will gain +1 attack.|
|Tribe Health|While a card bearing this sigil is on the board, all other cards on your side of the board of the same tribe will gain +1 health.|
|Velocity|At the end of the owner's turn, A card bearing this sigil will move in the direction inscribed in the sigil. If it is able to move, it will gain 1 power and 1 health.|
|Vicious|When A card bearing this sigil is attacked, it gains 1 power.|
|Warper|At the end of the owner's turn, the creature bearing this sigil will move to the right, it will jump over any creatures in its path, if it encounters the edge of the board, it will loop over to the other side.|
|Wild hunger|At the end of the owner's turn, the card bearing this sigil will move in the direction inscrybed in the sigil, but if it hits a card whilst moving, that card perishes and the card bearing this sigil gains 1+/1+.|
|Withering|A card bearing this sigil will perish at the end of the opponant's turn.|
|Zapper|When A card bearing this sigil damages another creature, that creature will gain the Paralysis Sigil. The Paralysis sigil is defined as: A card bearing this sigil only attack every other turn.|
</details>
