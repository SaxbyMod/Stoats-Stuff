Other artworm after version 1.0.1 is either made by me or redthatcat

Meal worm image made by CHEESE#5715

Slenderdestroyer image made by Cevin2006 (◕‿◕)#7971

Changelog

1.0.0 added 10 cards

1.0.1 added P03 and fixed the elderly bear

1.0.2 added 10 more cards 