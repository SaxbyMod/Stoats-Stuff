### Changelog

1.0.0 The doctor and his tools

### Cards

14 Rares

3 Commons

### Whats to come

The Doctors ENEMIES

The Doctors COMPANIONS

The Shit I  Forgot About

### Info

Find A Bug report in https://discord.gg/3fqjBky4UR

Please dont Disable Vanila  cards till Companions or ENEMIES update is out.