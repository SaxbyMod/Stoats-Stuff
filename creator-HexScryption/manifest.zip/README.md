This is a act 1 mod that adds the hex characters Side characters soon

1.0.0 Base main characters

1.0.1 Added all swk characters