___
### Images

These were found on the wiki for the hex and I used those to make the cards

Bitty45 Made This packs pack icon

___
### Includes:

<details>
<summary>20 New Cards:
</summary>

|Name|Power|Health|Cost|Sigils|Specials|Traits|
|:-|:-|:-|:-|:-|:-|:-|
|Captain Barnay|2|4| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Skeleton Crew|||
|Catarina|0|3| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Many Lives, Looter|Cat||
|Great Sage|3|1| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Brittle|||
|Groonda|1|2| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Sharp Quills, Guardian||Uncuttable|
|Irving|3|2| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Unkillable|||
|Jack|1|3| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Made Of Stone|||
|Jay|3|3| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Sniper|||
|Jerimiah|1|2| <img align="center" src="https://i.imgur.com/H6vESv7.png">|Bone Digger|||
|Junior|2|2| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Rabbit Hole, Sprinter|||
|Moglee|2|4| <img align="center" src="https://i.imgur.com/Ckvc6Ww.png">|Super Sprinter|||
|Moji|2|3| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Rabbit Hole|||
|Mr. Shrewd|2|1| <img align="center" src="https://i.imgur.com/H6vESv7.png">|Hoarder|||
|Mr. Squarrel|Mirror|3| <img align="center" src="https://i.imgur.com/H6vESv7.png">|Guardian|Mirror||
|Rebecha|3|3| <img align="center" src="https://i.imgur.com/Ckvc6Ww.png">|Battery Bearer|||
|Sado|3|1| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Unkillable|||
|The Great Kraken|2|3| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Waterborne|||
|Tropical Steam Bot|2|2| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Trinket Bearer|||
|Vallimir|2|2| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Handy|||
|Villager|2|4| <img align="center" src="https://i.imgur.com/Ckvc6Ww.png">|Swapper|||
|Wizarro|2|3| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Fecundity|||
</details>

<details>
<summary>5 New Rare Cards:
</summary>

|Name|Power|Health|Cost|Sigils|
|:-|:-|:-|:-|:-|
|Chandrelle|4|2| <img align="center" src="https://i.imgur.com/Ckvc6Ww.png">|Leader|
|Chef Bryce|2|1| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Double Strike|
|Lazarus|4|3| <img align="center" src="https://i.imgur.com/Ckvc6Ww.png">|Energy Gun|
|Rootbeer Reggie|2|4| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Trinket Bearer|
|Super Weasel Kid|2|3| <img align="center" src="https://i.imgur.com/62GUUAC.png">|Jumper|
</details>
